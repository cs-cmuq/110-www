def count_occurrences(s, ss):
    return

def slice_shift(l, pos_from, pos_to):
    return

def decimal_to_binary(d):
    return

def likes(d, person):
    return

def compute_grades(filename):
    return

