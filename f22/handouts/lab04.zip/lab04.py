#### rollerCoaster ####

def rollerCoaster(L, mn, mx):
    return 42


#### jumpingFrog ####

def jumpingFrog(P, h):
    return "42"


#### cheapest ####

def cheapest(L):
    return 42
