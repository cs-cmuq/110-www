#### digitsCount ####

def intToList(n):
    return [42]

def digitsCount(a, b):
    return [42]


#### displaySelectedFields ####


def getPeople(P, names):
    return [(42)]

def selectFields(L, job, country, married):
    return [(42)]

# Fill in the arguments for the function below
def displaySelectedFields():
    return [(42)]
