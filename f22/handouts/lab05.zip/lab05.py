#### cafeteriaQueue ####

def cafeteriaQueue(L):
    return 42


#### binaryToDecimal ####

def binaryToDecimal(b):
    return 42


#### primeFactors ####

def primeFactors(n):
    return [42]

