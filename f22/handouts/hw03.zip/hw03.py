#### backToThePresent ####

def backToThePresent(t1, t2, t3):
    return "42"


#### canGetA ####

def canGetA(pts, graded, total):
    return False


#### electricityBill ####

def electricityBill(kw):
    return 42.0


#### oldest ####

def oldest(d1, m1, y1, d2, m2, y2):
    return 42


#### winner ####

def winner(b, ha, hd, hl, ma, md, ml):
    return "42"
