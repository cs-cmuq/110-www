def sum_odd_numbers(n):
    odds_sum = 0
    for i in range(  ,  ,  ):
        odds_sum 
    return odds_sum


def sum_and_extend(L):
    if len(L) 
        cnt = 0
        while True:
            new_val = L[-1] + 
            if new_val < 100:
                L.
                cnt +
            else:
                return (new_val,   )
    else:
        return (None,    )

    
def discount_products(L, discount, value, max_items):
    discounted_items = 0
    index = 0
    while discounted_items
        if L[     ] >= value:
            L[    ] *= discount
            discounted_items += 
        index += 1
    
    

def get_average_price(car_infos, ref_year):
    return ()


def compare_strings(L):
    return 
        
