def split_by_type(L):
    return []


def binary_to_decimal(b):
    return 

def decimal_to_binary(d):
    return 



def simple_subseq_match(sequence, subseq):
    return 

def subseq_match(sequence, subseq):
    return 


# Begin hangman code

# End hangman code



def check_value(e):
    return

def find_minimum(L):
    return



#import 
#import 

def plot_points(x, y, line=True):
    plt.figure()
    plt.xlabel('x')
    plt.ylabel('y')
    if line:
        linestyle = '-'
        plt.plot(x, y, marker='.', linestyle=linestyle)
    else:
        linestyle = ''
        plt.plot(x, y, marker='.', linestyle=linestyle)
    

def plot_function(f, xmin, xmax, step, lines=True):
    
def parabola(x):
    return

def cubic(x):
    return

def periodic(x):
    return 

