def chocolate_package(small, big, goal):
    return

def longest_increasing_subseq(x):
    return

def read_temperatures(filename);
    return

def get_statistics(temperature_dict):
    return

def display_trend(temperature_dict):
    return

def display_aggregate(temperature_dict):
    return

