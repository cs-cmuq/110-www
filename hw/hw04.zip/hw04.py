def get_middle(l):
    return
    

def info_tuple(first_name,last_name, major, gpa):
    return


def join_ends(l1, l2):
    L = []
    L += l1
    L += 
    if  L[0] == L[-1]:

    else:
        return 

    
def nested_lists(l, i, j, k):
    if len(l) >= 
        if len(l[i]) 
            if type(l[i][j]) == str:
                if len(l[i][j])
                    return 
    return None


def swap(l, i, j):
    return 



def to_thirds(l):
    if len(l) 
        return None
    one_third = 
    two_thirds = one_third * 2
    t = (l[0:one_third],               , l[two_thirds:])
    if t[0] > t[1]:
        if t[0] > 
            print("Sublist 0 has max value")
        else:
            print(                          )
    elif t[1] > t[2]:
        print("Sublist 1 has max value")
    else:


        
def slice_shift(l, pos_from, pos_to):
    return

