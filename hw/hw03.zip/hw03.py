def evens(s):
    return 

def extract_data(s, n):
    return

def palindrome(s):
    return
    
def count_occurrences(s, ss):
    return

def is_valid_filename(s):
    return
    



