def single_eaters(eatsMeat, eatsPlants, animalList):
    return 

def bad_friend_score(d, person):
    return 

def likes(d, person):
    return

def antisocial_score(d, person):
    return

def filterText(text):
    return

def most_common_word(text):
    return 

def compute_grades(filename):
    return 
