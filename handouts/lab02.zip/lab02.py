#### letterGrade ####

def letterGrade(pts, total):
    return "42"


#### leapYear ####

def leapYear(y):
    return True


#### calculateAge ####

def calculateAge(bd, bm, by, d, m, y):
    return 42


#### getInRange ####

def getInRange(x, bound1, bound2):
    return 42.0

