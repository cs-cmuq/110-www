
#### palindrome ####

def palindrome(s):
    return True


#### isValidFilename ####

def isValidFilename(s):
    return True



#### tautogram ####

def tautogram(S):
    return True

