#### diagnose ####

def diagnose(d, s):
    return []


#### antisocialScore ####

def antisocialScore(s):
    return {}


#### groceriesShopping ####

def adjustPrice(pd, prod, adj):
    return {}


def restock(sd, new):
    return {}


def computeTotal(pd, cart):
    return 42.0

