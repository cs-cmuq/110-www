#### pythagoras ####

def pythagoras(a, b):
    return 42


#### circleArea ####

def circleArea(r):
    return 42.0


#### computeSpeed ####

def computeSpeed(kms, minutes):
    return 42.0


#### computeSeconds ####

def computeSeconds(h, m, s):
    return 42

