#### familyTree ####

def familyTree(filename):
    return {}


def grandchildren(p, ft):
    return []


def grandparents(p, ft):
    return []

