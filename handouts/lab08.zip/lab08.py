#### alphabeticalGrades ####

def alphabeticalGrades(d):
    return []


#### wordCount ####

def wordCount(doc):
    return {}


#### numberOfFriends ####

def numberOfFriends(pairs):
    return {}

