import math

#### cubicBoxes ####

def cubicBoxes(n1, n2):
    return 42


#### hotdogPurchase ####
        
def hotdogPurchase(numHotdogs):
    return (42,42)


#### hotdogExcess ####

def hotdogExcess(numHotdogs):
    return (42, 42)


#### getKthDigit ####

def getKthDigit(num, pos):
    return 42

